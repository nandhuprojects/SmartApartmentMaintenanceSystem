import React, { useState } from "react";
import { useHistory } from "react-router-dom"; // For navigation in React Router v5

const ManageUsers = () => {
    const history = useHistory(); // Initialize useHistory

    const [user, setUser] = useState({
        first_name: "",
        last_name: "",
        username: "",
        password: "",
        mobile: "",
        role: "tenant"
    });

    const handleChange = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const response = await fetch("http://localhost:8082/addUser", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(user),
        });
        const result = await response.json();
        alert(result.message);
        
        // Clear form after submission
        setUser({
            first_name: "",
            last_name: "",
            username: "",
            password: "",
            mobile: "",
            role: "tenant"
        });
    };

    return (
        <div className="manage-users-container">
            {/* Back button positioned at the top-left */}
            <button className="back-button" onClick={() => history.goBack()}>← Back</button>

            <h2 className="manage-users-title">Add User</h2>
            <form className="manage-users-form" onSubmit={handleSubmit}>
                <input className="manage-users-input" type="text" name="first_name" placeholder="First Name" value={user.first_name} onChange={handleChange} required />
                <input className="manage-users-input" type="text" name="last_name" placeholder="Last Name" value={user.last_name} onChange={handleChange} required />
                <input className="manage-users-input" type="text" name="username" placeholder="Username" value={user.username} onChange={handleChange} required />
                <input className="manage-users-input" type="password" name="password" placeholder="Password" value={user.password} onChange={handleChange} required />
                <input className="manage-users-input" type="text" name="mobile" placeholder="Mobile" value={user.mobile} onChange={handleChange} required />
                <select className="manage-users-select" name="role" value={user.role} onChange={handleChange}>
                    <option value="tenant">Tenant</option>
                    <option value="owner">Owner</option>
                    <option value="association">Association</option>
                    <option value="security">Security</option>
                    <option value="housekeeper">Housekeeper</option>
                </select>
                <button className="manage-users-button" type="submit">Add User</button>
            </form>
        </div>
    );
};

export default ManageUsers;
